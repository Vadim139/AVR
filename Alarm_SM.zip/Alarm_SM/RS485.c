/*
 * RS485.cpp
 *
 *  Created on: 16 gru 2017
 *      Author: Vadim
 */

#include "RS485.h"

void RS485_Init() {

	MAX_RW_DDR = 1;
	MAX_RW = 0;
	uart_init((UART_BAUD_SELECT((BAUD),xtalCpu)));
}

uint8_t RS_Transfer(uint8_t addr, uint8_t data)
{
	MAX_EnableWrite();
	_delay_ms(20);

	uart_putc(addr);
	_delay_us(20);

	uart_putc(data);
	_delay_us(20);

	uart_putc(addr);
	_delay_ms(20);

	MAX_DisableWrite();
	_delay_ms(20);
	return 0;

}

uint8_t RS_TransferMulti(uint8_t addr, uint8_t* data, uint8_t size)
{
	MAX_EnableWrite();
	_delay_ms(20);
	uart_putc(addr);
	_delay_us(20);

	for(int i = 0; i < size; i++){
		uart_putc(data[i]);
		_delay_us(20);
	}
	uart_putc(addr);
	_delay_ms(20);
	MAX_DisableWrite();
	_delay_ms(20);
	return 0;

}

uint8_t RS_Receive()
{
	uint8_t rec = 0;

	if(Is_Data())
		rec = uart_getc();
//	while(USART_GetFlagStatus(RC_USART, USART_FLAG_) == RESET);
//	delay_ms(20);

	return rec;

}

uint8_t RS_Receive_Multi(uint8_t* data)
{
	uint8_t i = 0;

	while(!Is_Data());
	_delay_ms(10);

	while(Is_Data()){
		data[i] = uart_getc();
		_delay_us(10);
		i++;
	}
//	while(USART_GetFlagStatus(RC_USART, USART_FLAG_) == RESET);
//	delay_ms(20);
	data[i] = 0;
	return i;

}

void MAX_EnableWrite()
{
    // Set slave SS pin low
	MAX_RW = 1;
}

void MAX_DisableWrite()
{
    // Set slave SS pin high
	MAX_RW = 0;
}


