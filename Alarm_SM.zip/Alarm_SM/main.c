/*===========================================================================================================================
 * main.c
 *
 *  Created on: 09-02-2012
 *      Author: Krzysztof Szromek
 *      Poligon doswiadczalny w obs�udze uart i RTC (poprzez TWI).
 *      Kod do obs�ugi poszczeg�lnych element�w podzielony na osobne biblioteki.
 *		- uart_lib
 *		- lcd_drv
 *		- keypad
 *
 *      Konfiguracja sprz�towa:
 *      PD.0 	- RxD
 *      PD.1 	- TxD
 *      PC.0-3 	- ROW_1-4  	- 4 linie wierszy klawiatury matrycowej
 *      PD.2 	- KEYINT 	- przerwanie z klawiatury
 *      PB.0-3 	- LED 		- 4x Ledy
 *
 *===========================================================================================================================*/

//#include <avr/io.h>
//#include <avr/interrupt.h>
//#include <stdlib.h>
//#include <string.h>
//#include <util/delay.h>

//#include "my_defs.h"
//#include "sbit.h"
//#include "lcd_drv.h"
#include "main.h"
#include "keypad.h"
//#include "RC522.h"
#include "MFRC522.h"
#include "ds18b20.h"
//#include "uart.h"
//#include "I2C_slave.h"

char buffer[3];
uint8_t ID[6] = {0,0,0,0,0,0};
//extern volatile unsigned char UART_RxHead;
//extern volatile unsigned char UART_RxTail;

double temp;
/* W tablicy zapisywane b�d� dane odczytane z uk�adu ds18b20 */
unsigned char ds18b20_pad[9];

#define block	0
unsigned char seck[] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
volatile char rec = 0;
volatile char INT = 0;
volatile char buf[20];
volatile uint8_t *blad = 0;
unsigned char roz = 0;
unsigned char status, str[20];
int main(void) {
	int i = 0;

	LED_DDR_1 = 1;
//	LED_DDR_2 = 1;
//	LED_DDR_3 = 1;
//	LED_DDR_4 = 1;
//	LED_DDR_5 = 1;
//	LED_DDR_6 = 1;
//	LED_DDR_7 = 1;
//	LED_DDR_2 = 1;

	SB_RW_DDR = 0;
	SB_RW = 1;

	LED_1 = 1;
//	LED_2 = 1;
//	LED_3 = 1;
//	LED_4 = 1;
//	LED_5 = 1;
//	LED_6 = 1;
//	LED_7 = 1;

	TCCR1B = 0b00001100;
	TIMSK1 = 0x03;
	OCR1A = 62500;

	RS485_Init();

	EICRA = ((0 << ISC01) & (0 << ISC11)); // INT0 executed on falling edge
	EIMSK |= (1 << INT0) | (1 << INT1) ;

	lcd_init();

	lcd_blank();
	lcd_xy(0,0);
	lcd_puts("STM32");

//	SPIInit();
//	spi_master_init();
//	RC522_Init();
	MFRC522_Init();
	_delay_ms(500);

//	KEYINT = 0;			// set key interrupt pins as input with pull-up
//	KEYINT_DDR = 0;
//
//	ROW_1 = 	0; 		// set row pins as input with pull-up dir == ROWS
//	ROW_DDR_1 =  1;		// 0 when dir == ROWS
//	ROW_2 = 	0;		// 1 when dir == ROWS
//	ROW_DDR_2 =  1;
//	ROW_3 = 	0;
//	ROW_DDR_3 =  1;
//	ROW_4 = 	0;
//	ROW_DDR_4 =  1;
//
//
//	COL_1 = 	0; 		// set column pins as output low when dir == ROWS
//	COL_DDR_1 =  1;		// 1 when dir == ROWS
//	COL_2 = 	0;		// 0 when dir == ROWS
//	COL_DDR_2 =  1;
//	COL_3 = 	0;
//	COL_DDR_3 =  1;




//	DS_TEMP_DDR = 0;
//	DS_TEMP = 1;
	zmroz(2,1);
//	DS18B20_temp(0,0,1,&blad,1);
//	  LCD_DDR_D4 = 1;                               // enable output pins
//	  LCD_DDR_D5 = 1;
//	  LCD_DDR_D6 = 1;
//	  LCD_DDR_D7 = 1;
//	  LCD_DDR_RS = 1;
//	  LCD_DDR_E0 = 1;
//	  LCD_DDR_BL = 1;
//	  LCD_D4 = 1;
//	  LCD_D5 = 1;
//	  LCD_D6 = 1;
//	  LCD_D7 = 1;
//	  LCD_E0 = 1;
//	  LCD_RS = 1;
//	  LCD_BL = 1;// send commands

	keypad_init();


//	uart_init((UART_BAUD_SELECT((BAUD),xtalCpu)));

//	spi_init_slave();
	sei();

	for(i = 0;i<20; i++)
		buf[i] = 0;
//	flag = 0;
//	buffer_address = 0x00;

	while(1)
	{
//		DS18B20_(0,0,4,&blad,2);
		if(INT)
		{
			RS_Transfer(123,keypad_pressed);
			PORTD ^=(1<<5);
			INT = 0;
		}

		if(Is_Data()){
			rec = RS_Receive();
//		if ((rec = uart_getc()) != 0) {
////			uart_timeout_b = false;

			switch (rec) {
			case ADDR:
				rec = 0;
//				while(!(rec = uart_getc()));
				while(!Is_Data());
				rec = RS_Receive();
				switch (rec) {
					case 1:
						PORTD ^=(1<<5);
						break;
					case 2:
//						PORTD ^=(1<<6);
						break;
					case 3:
						rec = 0;
						RS_Receive_Multi(buf);
						lcd_blank();
						lcd_xy(0,0);
						lcd_puts(buf);
						break;
					case 10:
						LED_1 = 1;
//						RFID_CS = 1;
						break;
					case 11:
						LED_1 = 0;
//						RFID_CS = 0;
						break;
//					case 21:
//						RFID_SCK = 0;
//						RFID_SCK_DDR = 1;
//						RFID_MISO = 0;
//						RFID_MISO_DDR = 1;
//						RFID_MOSI = 0;
//						RFID_MOSI_DDR = 1;
//						RFID_CS = 0;
//						RFID_CS_DDR = 1;
//						break;
//					case 22:
//						RFID_SCK = 1;
//						RFID_SCK_DDR = 1;
//						RFID_MISO = 1;
//						RFID_MISO_DDR = 1;
//						RFID_MOSI = 1;
//						RFID_MOSI_DDR = 1;
//						RFID_CS = 1;
//						RFID_CS_DDR = 1;
//						break;
//					case 23:
//						RFID_SCK = 0;
//						RFID_SCK_DDR = 0;
//						RFID_MISO = 0;
//						RFID_MISO_DDR = 0;
//						RFID_MOSI = 0;
//						RFID_MOSI_DDR = 0;
//						RFID_CS = 0;
//						RFID_CS_DDR = 0;
//						break;
					case 254:
						RS_Transfer(254,253);
//						uart_putc(250);
//						uart_putc(253);
						break;
					default:
						break;
				}
				break;

			default:
				break;
			}
		}else{
//			RS_TransferMulti(0,"No input!\n\r",11);
//			uart_puts("No input!\n\r");
		}

//	    if(ds18b20_ConvertT())
//	    {
//
//	       /* 750ms - czas konwersji */
//	       _delay_ms(750);
//
//	      /* Odczyt z uk�adu ds18b20, dane zapisywane s� w tablicy ds18b20_pad.
//	         Dwie pierwsze pozycje w tablicy to kolejno mniej znacz�cy bajt i bardziej
//	     znacz�cy bajt warto�� zmierzonej temperatury */
//	       ds18b20_Read(ds18b20_pad);
//
//	      /* Sk�ada dwa bajty wyniku pomiaru w ca�o��. Cztery pierwsze bity mniej
//	         znacz�cego bajtu to cz�� u�amkowa warto�ci temperatury, wi�c ca�o��
//	         dzielona jest przez 16 */
//	       temp = ((ds18b20_pad[1] << 8) + ds18b20_pad[0]) / 16.0 ;
//
//	      /* Formu�uje komunikat w tablicy 'str' */
//	       sprintf(str,"%4.1f\xdf""C", temp);
//
//	       lcd_blank();
//	       lcd_xy(0,0);
//	      /* Wysy�a komunikat do wy�wietlacza */
//	       lcd_puts(str);
//	    }

		status = MFRC522_Request(PICC_REQIDL,str);
		if(status==MI_OK)
		{
//			lcd_blank();
			lcd_xy(0,0);
			lcd_puts("                ");
			lcd_xy(0,0);
			status = MFRC522_Anticoll(str);
 			RS_TransferMulti(250,str,5);
			for(unsigned char j=0;j<5;j++)
			{
				lcd_hex(str[j]);
				lcd_putchar(' ');
			}
//			status = MFRC522_SelectTag(str);
//			status = MFRC522_Auth(PICC_AUTHENT1A, block, seck, str);
//			status = MFRC522_Read(block, str);
//			MFRC522_Halt();
		}
		_delay_ms(1000);

	}

	return 0;
}


ISR(INT0_vect) {
	_delay_ms(100);
	if (KEYINT_R != 0)
		return;
	INT = 1;
//	PORTD ^=(1<<5);
	keypad_poll();

//	RS_TransferMulti(0,"No input!\n\r",11);
//	RS_Transfer(123,keypad_pressed);
//	uart_putc(254);
//	uart_putc(keypad_pressed);

	switch (keypad_pressed) {
	case KEY1:
		PORTD ^=(1<<5);
		break;
	case KEY2:
		PORTD ^=(1<<5);
		break;
	case KEY3:
		PORTD ^=(1<<5);
		break;
	case KEY4:
		PORTD ^=(1<<5);
		break;
	case KEY5:
		PORTD ^=(1<<5);
		break;
	case KEY6:
		PORTD ^=(1<<5);
		break;
	case KEY7:
		PORTD ^=(1<<5);
		break;
	case KEY8:
		PORTD ^=(1<<5);
		break;
	case KEY9:
		PORTD ^=(1<<5);
		break;
	case KEYSTAR:
		PORTD ^=(1<<5);
		break;
	case KEY0:
		PORTD ^=(1<<5);
		break;
	case KEYHASH:
		PORTD ^=(1<<5);
		break;
	default:
		break;
	}
}

ISR(INT1_vect)
{
	PORTD ^=(1<<5);
	_delay_ms(100);
}


ISR(TIMER0_OVF_vect)
{

}

ISR(TIMER1_COMPA_vect) {
	DS18B20_showtemp(7,1,2,&blad,1);
	DS18B20_ConvertT(&blad,1);
//		if(!RC522_Check((uint8_t*)ID)){
//			if(ID[0] != 0)
//				RS_TransferMulti(250,ID,5);
//		}
//	PORTD ^=(1<<5);
//	PORTA ^=(1<<1);
//	uart_puts("No input!\n\r");
}

