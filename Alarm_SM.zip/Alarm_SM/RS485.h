/*
 * RS485.h
 *
 *  Created on: 16 gru 2017
 *      Author: Vadim
 */

#include "main.h"
//#include "Timer.h"

#ifndef RS485_H_
#define RS485_H_

void RS485_Init();
uint8_t RS_Transfer(uint8_t addr, uint8_t data);
uint8_t RS_TransferMulti(uint8_t addr, uint8_t* data, uint8_t size);
uint8_t RS_Receive();
uint8_t RS_Receive_Multi(uint8_t* data);
void MAX_EnableWrite();
void MAX_DisableWrite();


#endif /* RS485_H_ */
